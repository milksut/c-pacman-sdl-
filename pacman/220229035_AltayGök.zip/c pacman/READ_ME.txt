w-a-s-d  are the move buttons
you cant stop unless hit a wall
esc stops the game press again to resume
when you die game stops you cant restart just relounch game
top numers are the time bottom ones is your point
you cant win even when you collect all the point